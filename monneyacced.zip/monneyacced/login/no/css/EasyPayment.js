﻿var isMobileDevice = !(chkMobileDevice === null || chkMobileDevice === undefined);

function ResetFeeInformation() {

    if ($("#okButton").length > 0) {
        RemoveTableRow('feeAmountRow');
        var payText = $("#okButton").val().split(' ')[0];
        if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "true") {
            $("#okButton").val(payText + " " + $('#amount').text());
        }
        else {
            $("#okButton").val(payText);
        }
        RemoveTableRow('roundingAmountRow');
        RemoveTableRow('totalAmountRow');
        //$("#amountLabel").css("font-weight", "bold");
        //$("#amount").css("font-weight", "bold");
    }
    if ($("#payButton").length > 0) {
        var payText = $("#payButton").val().split(' ')[0];
        if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "true") {
            $("#payButton").val(payText + " " + $('#amount').text());
            $("#feeSection").hide();
        }
        else {
            $("#payButton").val(payText);
            //RemoveTableRow('feeAmountRow');
            //RemoveTableRow('totalAmountRow');
        }


    }


    if (isMobileDevice === false) { ResetIssuerInformation(); }

}

function GetIssuer2(CardNoControlId) {
    // TODO workaround for Discover
    easyPaymentDiscoverFlag = ($("#" + easyPaymentCardNoId).val().indexOf("6011") === 0);
    GetIssuer(CardNoControlId);
}

// called from ./Scripts/Common.js by OnGetIssuerComplete(issuerDetails) function
function ShowFee(issuerId, fees, rounding, totalAmount) {
    if (!isMobileDevice) { ResetFeeInformation(); }

    if (totalAmount !== '' && totalAmount.includes(':')) {
        var totalAmountSplit = totalAmount.split(':');
        if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "false") {
            var totalamt = totalAmountSplit[0] + ': ' + totalAmountSplit[1].replace(/\s/g, '');
            totalAmount = totalamt.replace('(', ' (');
        }
        else {
            var totalamt = totalAmountSplit[0] + ': ' + totalAmountSplit[1];
        }
    }

    var previousRowId = 'amountRow';
    if (isMobileDevice === false) {
        previousRowId = AssignAmountTextTr('feeAmountRow', '', fees, previousRowId);
        previousRowId = AssignAmountTextTr('roundingAmountRow', '', rounding, previousRowId);
        previousRowId = AssignAmountTextTr('totalAmountRow', '', totalAmount, previousRowId);

    }
    if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "false") {
        $("#tdtotalAmountRow").attr("class", "lineTop");
        if (isMobileDevice === false) { $("#totalAmountNumrow").attr("class", "lineTop"); }

    }

    if (isMobileDevice === false) { HandleIssuerImage(issuerId); }
}


function AssignAmountTextTr(rowId, classId, textString, previousRowId) {
    if (textString && textString !== "0") {
        var textArray = textString.split(':', 2);
        $('<tr role=presentation id ="' + rowId + '"><th  id ="th' + rowId + '" style="text-align:left;font-weight:bold;" role="presentation" scope="row">' + textArray[0] + ':</th><td  id ="td' + rowId + '" role=presentation' + (classId ? ' class="' + classId + '"' : '') + '>'
            + textArray[textArray.length - 1] + '</td></tr>').insertAfter($('#' + previousRowId)); // set to last part of the text
        return rowId;
    }
    return previousRowId;
}

function HandleIssuerImage(issuerId, isDiscover) {
    var image;
    var issuerName = '';
    if (isDiscover != null) {
        easyPaymentDiscoverFlag = isDiscover;
    }

    if (easyPaymentIssuers.hasOwnProperty(issuerId)) {
        var issuerObj = easyPaymentIssuers[issuerId];
        // TODO workaround for Discover
        if (issuerId === "6" && easyPaymentDiscoverFlag)
            issuerObj = easyPaymentDiscover;

        image = $("#" + issuerObj.imageId);
        issuerName = issuerObj.issuerName;
    }
    else {
        ResetIssuerInformation();
        return;
    }

    if (image === null || image.attr('src') === null) {
        ResetIssuerInformation();
        return;
    }
    else {
        Select(image, issuerName, issuerId);
    }
}

function RemoveTableRow(trId) {
    $('#' + trId).remove();
}

$(document).ready(function () {
    $("#" + easyPaymentCurrentIssuerImageId).hide();

});

function Select(image, issuerName, issuerId) {
    var selectedSource = image.attr('src').replace('NotSelected/', '');
    var currentIssuerImage = $("#" + easyPaymentCurrentIssuerImageId);

    image.attr('src', selectedSource);
    currentIssuerImage.attr('src', selectedSource).show();

    $("#EasyPayment_currentIssuerImage").attr('alt', issuerName);
    if (isMobileDevice == false) {
        HideSecurityCode(issuerName);
    }
}

function HideSecurityCode(issuerName, issuerId) {
    if ((easyPaymentvalidationRequired === "False" && issuerName === "Maestro") || issuerId === "32" || issuerId === "49") {
        $("#" + easyPaymentverificationLabel).hide();
        $("#" + easyPaymentsecurityCode).hide();
        $("#" + easyPaymentpopupLink).hide();

    } else {
        $("#" + easyPaymentverificationLabel).show();
        $("#" + easyPaymentsecurityCode).show();
        $("#" + easyPaymentpopupLink).show();
    }

}

function ResetIssuerInformation() {
    $("#" + easyPaymentCurrentIssuerImageId).hide();

    for (var issuerId in easyPaymentIssuers) {
        if (easyPaymentIssuers.hasOwnProperty(issuerId)) {
            var issuerObj = easyPaymentIssuers[issuerId];
            $("#" + issuerObj.imageId).attr('src', '/Images/Issuers/Icons/NotSelected/' + issuerObj.imageFile);
        }
    }
    // TODO workaround for Discover
    if (typeof easyPaymentDiscover !== 'undefined')
        $("#" + easyPaymentDiscover.imageId).attr('src', '/Images/Issuers/Icons/NotSelected/' + easyPaymentDiscover.imageFile);
}
