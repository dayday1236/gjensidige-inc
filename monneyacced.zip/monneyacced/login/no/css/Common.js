﻿var easyPaymentLastCardLookup = null;
var isMobileDevice = !(chkMobileDevice === null || chkMobileDevice === undefined);
var isCustomTemplate = (chkMobileDevice === false);
$(document).ready(function () {
    $("#trGenericCardPayment").click(function () {
        GetIssuer('cardNumber');
    });

    $("#divGenericSinglePayment").click(function () {
        GetIssuer('cardNumber');
    });

    if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "true") {


        $("#txtExpiryDate").keyup(function (e) {
            if (e.keyCode != 8) {
                if ($(this).val().length == 2) {
                    $(this).val($(this).val() + "/");
                }
                if ($(this).val().length == 5) {
                    $("#securityCode").focus();
                }
            }
        });
        function handleSubmit(e) {
            if (e.which == 13)
                $("#okButton").click();

            var isPatternExits = (this.pattern != undefined && this.pattern.length != 0);
            if (e.which == 0 || e.which == 8)
                return true;
            else if ((e.which < 48 || e.which > 57) && !isPatternExits)
                return false;

            return true;
        }

        $("#cardNumber").keypress(handleSubmit);

        $("#securityCode").keypress(handleSubmit);

        $("#txtExpiryDate").keypress(handleSubmit);

        var issuer = $("#hdnIssuer").val(); //2 - page terminal
        if (issuer) {
            if (issuer == "5" || issuer == "50000" || issuer == "50001" || issuer == "6") { //Amex- 5,AmexDebitSEK-50000,AmexCreditSEK-50001,Diners - 7
                CardGroupForAmex();
            }
            else {
                CardGroupForRest();
            }
        }
        AdjustPadlockPositionLoad();
        AdjustPadlockPositionLoadMobile();
    }
});

function GetIssuer(CardNoControlId) {
    var c = $("#" + CardNoControlId);
    var sessionId = easyPaymentEpaySessionId;
    var mif = $("#mifDiv");
    var acqID = $("#hdnMerchandAcqID").val();
    if (c.length) // control found
    {
        var cardNumber = c.val();
        if (cardNumber.length <= 3) {
            mif.fadeOut();
            ResetFeeInformation();
            return;
        }
        if (document.getElementById("terminalDesign") != null) {
            if (document.getElementById("terminalDesign").value == "true") {
                if (4 < cardNumber.length && cardNumber.length < 6) {
                    var formattedcardNo = GroupCardNumber(CardNoControlId, null);
                    cardNumber = formattedcardNo.replace(/\s/g, '');
                }

                cardNumber = cardNumber.replace(/\s/g, '');
            }
        }
        if ((cardNumber.length >= 6) && (cardNumber.includes('**'))) {
            cardNumber = cardNumber.substring(0, 6);
            fetchIssuerDetails(cardNumber, sessionId);
        }
        else {
            easyPaymentLastCardLookup = cardNumber;
            fetchIssuerDetails(cardNumber, sessionId);
        }
        if (cardNumber.substring(0, 4) == "4571" && acqID != null && acqID.startsWith("208")) {
            if (mif != null) {
                if (document.getElementById("terminalDesign").value == "true") {
                    mif.fadeIn();
                } else { mif.css("display", "inline"); }

            }
        }
        else {

            if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "true") {
                mif.fadeOut();
            } else { mif.css("display", "none"); }

        }
    }
    else {
        ResetFeeInformation();
        return;
    }
}

function fetchIssuerDetails(cardNumber, sessionId) {

    try {
        var userContext = null;
        var terminalProxy = Netaxept.Web.Terminal.Webservices.Terminal;
        terminalProxy.set_timeout(5000); // sometimes onReadyStateChange event is not triggered on firefox, so need to check for timeout in addition then
        terminalProxy.GetIssuerDetails(cardNumber, sessionId, window.OnGetIssuerComplete, window.OnGetIssuerFailed, userContext);
    }
    catch (err) {
        var code = err.toString()
        ResetFeeInformation();
        return;
    }
}

function FormatAmount(amount) {
    var amt = amount.replace(/[()]/g, '');
    var formattedAmount = amt;
    if (amt.indexOf("DKK") > -1) {
        formattedAmount = amt.replace("DKK", "kr");
    }
    if (amt.indexOf("NOK") > -1) {
        formattedAmount = amt.replace("NOK", "kr");
    }
    if (amt.indexOf("SEK") > -1) {
        formattedAmount = amt.replace("SEK", "kr");
    }
    if (amt.indexOf("EUR") > -1) {
        formattedAmount = amt.replace("EUR", "€");
    }
    return formattedAmount;
};

function OnGetIssuerComplete(issuerDetails) {
    var issuerDetailsArray = jQuery.parseJSON(issuerDetails);
    if (document.getElementById("terminalDesign") != null) {
        if ($("#dvExpiryDate").is(":visible") == false && document.getElementById("terminalDesign").value == "true") {
            $("#dvSecuritycode").css("border", "1px solid #bbb");
            $("#dvSecuritycode").css("border-top", "none");
        }
    }
    if (issuerDetails !== '0') {
        var issuerId = issuerDetailsArray.IssuerId;
        if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "true") {
            GroupCardNumber("cardNumber", issuerId);
        }

        window.tdsMethodIssuerId = issuerId;
        var fees = "";
        var rounding = "";
        var totalAmount = "";
        if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "true") {
            fees = (issuerDetailsArray.Fee !== null ? ((issuerDetailsArray.Fee !== undefined && issuerDetailsArray.Fee.length > 0) ? FormatAmount(issuerDetailsArray.Fee) : '') : '');
            rounding = (issuerDetailsArray.Rounding !== null ? ((issuerDetailsArray.Rounding !== undefined && issuerDetailsArray.Rounding.length > 0) ? FormatAmount(issuerDetailsArray.Rounding) : '') : '');
            totalAmount = (issuerDetailsArray.TotalAmount !== null ? ((issuerDetailsArray.TotalAmount !== undefined && issuerDetailsArray.TotalAmount.length > 0) ? FormatAmount(issuerDetailsArray.TotalAmount) : '') : '');
        }
        else {
            fees = (issuerDetailsArray.Fee !== null ? ((issuerDetailsArray.Fee !== undefined && issuerDetailsArray.Fee.length > 0) ? issuerDetailsArray.Fee : '') : '');
            rounding = (issuerDetailsArray.Rounding !== null ? ((issuerDetailsArray.Rounding !== undefined && issuerDetailsArray.Rounding.length > 0) ? issuerDetailsArray.Rounding : '') : '');
            totalAmount = (issuerDetailsArray.TotalAmount !== null ? ((issuerDetailsArray.TotalAmount !== undefined && issuerDetailsArray.TotalAmount.length > 0) ? issuerDetailsArray.TotalAmount : '') : '');
        }

        if (fees !== '') {
            var fee = fees.split(':');
            if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "false") {
                fees = fee[0] + ': ' + fee[1].replace(/\s/g, '');
                fees = fees.replace('(', ' (');
            }
            else {
                fees = fee[0] + ': ' + fee[1];
            }
        }
        ShowFee(issuerId, fees, rounding, totalAmount);
        if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "true") {
            if (fees != "") {
                if ($("#okButton").length > 0) {
                    var payText = $("#okButton").val().split(' ')[0];
                    $("#okButton").val(payText + " " + $('#totalAmountRow').find('td:nth-child(2)').text());
                }
                if ($("#payButton").length > 0) {
                    var payText = $("#payButton").val().split(' ')[0];
                    $("#payButton").val(payText + " " + $('#totalAmount').text());
                }
            }

            var isDiscover = ($("#cardNumber").val().indexOf("6011") === 0 ? true : false);
            HandleIssuerImage(issuerId, isDiscover);
        }
        $("#feeLabel").show();
        $("#feeSection").show();
        $("#feeDetails").show(); 
        if ((issuerId == '92' && $("#cardNumber").val().substring(0, 4) == "9752")) {
            $("#dvSecuritycode").hide();
        } else {
            $("#dvSecuritycode").show();
        }
        if ((issuerId === '3') || (issuerId === '4') || (issuerId === '5') || (issuerId === '6') || (issuerId === '50')) {
            $("#StoreCredential_Nemlig").show();
            $("#storecredentialoptionhelpiconContainer").show();
            $("#storecredentialoptionchkContainer").show();

        }
        else {
            $("#StoreCredential_Nemlig").hide();
            $("#storecredentialoptionhelpiconContainer").hide();
            $("#storecredentialoptionchkContainer").hide();
        }
        if (isCustomTemplate === true) {
            return;
        }
        if (isMobileDevice === false) {
            HandleIssuerImage(issuerId);
        }
        if (isMobileDevice === true) {
            $("#roundingAmountRow").hide();
            $("#totalAmountRow").hide();
            $("#totalAmount").removeAttr("lineTop");
            if (document.getElementById("terminalDesign") != null) {
                if (document.getElementById("terminalDesign").value == "false") {
                    $("#feeLabel").text(fees);
                }
                if (fees === '' && document.getElementById("terminalDesign").value == "true") {
                    $("#feeamountRow").hide();
                }
            }

            if (rounding !== '') {
                $("#roundingAmountRow").show();
                var roundingSplit = rounding.split(':');
                var roundingLabelBold;
                if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "true") {
                    roundingLabelBold = roundingSplit[0] + '<b>' + ":" + '</b>' + '&nbsp;';
                }
                else { roundingLabelBold = '<b>' + roundingSplit[0] + '</b>' + '<b>' + ":" + '</b>' + '&nbsp;'; }

                $("#roundingLabel").html(roundingLabelBold);
                $("#rounding").html(roundingSplit[1]);
            }
            if (rounding !== '' || fees !== '') {
                $("#totalAmount").attr("class", "lineTop");
                $("#totalAmountRow").show();
                var totalAmountSplit = totalAmount.split(':');
                var totalAmountLabelBold = '<b>' + totalAmountSplit[0] + '</b>' + '<b>' + ":" + '</b>' + '&nbsp;';
                $("#totalAmountLabel").html(totalAmountLabelBold);
                var totalamt = totalAmountSplit[1];
                if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "false") {
                    totalamt = totalamt.replace(/\s/g, '');
                    totalamt = totalamt.replace('(', ' (');
                }
                $("#totalAmount").html(totalamt);
                if (document.getElementById("terminalDesign") != null && document.getElementById("terminalDesign").value == "true") {
                    $("#amountLabel").addClass('amountFont');
                    $("#amount").addClass('amountFont');
                    var splitfee = fees.split(':');
                    $("#fee").text(splitfee[1]);
                    $("#feeamountRow").addClass('feeamountDispaly');

                }

            }          
            if ((issuerId === '14' && validationRequiredforMaestro === 'False') || issuerId === '32' || issuerId === '49' || (issuerId == '92' && $("#cardNumber").val().substring(0, 4) == "9752")) {
                $("#" + verificationLabel).hide();
                $("#" + securityCode).hide();
                $("#securityCodeLabel").hide();
                $("#cvcDiv").hide();
            } else {
                $("#" + verificationLabel).show();
                $("#" + securityCode).show();
                $("#securityCodeLabel").show();
                $("#cvcDiv").show();
            }

        }
    }
}

function OnGetIssuerFailed(webServiceError, userContext, methodName) {
    var attributesLength = arguments.length;
    easyPaymentLastCardLookup = null;
}

function GetIssuerforEasypaymentMini(CardNoControlId) {
    var c = $("#" + CardNoControlId);
    var mif = $("#mifDivEasy");
    var acqID = $("#hdnMerchandAcqID").val();
    if (c.length) // control found
    {
        var cardNumber = c.val();
        if (cardNumber.length <= 3) {
            mif.fadeOut();
            $("#securityCode").css("margin-left", "0px");
            $("#securityCodeLabel").css("margin-left", "0px");
            $("#DivEasyMiniImage").css("width", "272px");
            return;
        }
        try {
            var userContext = null;
            var terminalProxy = Netaxept.Web.Terminal.Webservices.Terminal;
            terminalProxy.set_timeout(5000); // sometimes onReadyStateChange event is not triggered on firefox, so need to check for timeout in addition then
            terminalProxy.GetIssuerDetails(cardNumber, easyPaymentEpaySessionId, window.OnGetIssuerCompleteforEasypaymentMini, window.OnGetIssuerFailedforEasypaymentMini, userContext);
        }
        catch (err) {
            var code = err.toString();
            return;
        }
        if (cardNumber.substring(0, 4) == "4571" & acqID != null && acqID.startsWith("208")) {
            if (mif != null) {
                if (document.getElementById("terminalDesign").value == "true") {
                    mif.fadeIn();
                }
                else {
                    mif.css("display", "inline");
                    $("#securityCode").css("margin-left", "24px");
                    $("#securityCodeLabel").css("margin-left", "24px");
                    $("#DivEasyMiniImage").css("width", "162px");
                }
            }
        }
        else {
            if (document.getElementById("terminalDesign").value == "true") {
                mif.fadeOut();
            }
            else { mif.style.display = "none"; }
        }
    }
    else {
        return;
    }
}

function OnGetIssuerCompleteforEasypaymentMini(issuerDetails) {
    var issuerDetailsArray = jQuery.parseJSON(issuerDetails);
    var issuerId = issuerDetailsArray.IssuerId;
    if ((issuerId === '14' && validationRequiredforMaestro === 'False') || (issuerId == '92' && $("#cardNumber").val().substring(0, 4) == "9752")) {
        $("#" + securityCode).hide();
        $("#" + securityCodeLabel).hide();
        $("#" + helpLink).hide();
    } else {       
        $("#" + securityCode).show();
        $("#" + securityCodeLabel).show();
        $("#" + helpLink).show();
    }
    if ((issuerId === '3') || (issuerId === '4') || (issuerId === '5') || (issuerId === '6') || (issuerId === '50')) {
        $("#StoreCredential_Nemlig").show();
        $("#storecredentialoptionhelpiconContainer").show();
        $("#storecredentialoptionchkContainer").show();

    }
    else {
        $("#StoreCredential_Nemlig").hide();
        $("#storecredentialoptionhelpiconContainer").hide();
        $("#storecredentialoptionchkContainer").hide();
    }
}

function OnGetIssuerFailedforEasypaymentMini(webServiceError, userContext, methodName) {
    var attributesLength = arguments.length;
}

function BindModalPopup() {
    var modal = document.getElementById("myModal");
    var imagelink = document.getElementById("popupLinkOldTerminal");
    var span = document.getElementsByClassName("close")[0];

    if (imagelink != null) {
        imagelink.onclick = function () {
            modal.style.display = "block";
        };
    }

    span.onclick = function () {
        modal.style.display = "none";
    };

    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    };
}

function CardGroupForAmex() {
    this.value = this.value.replace(/[^0-9 \/]/g, '');
    $('#cardNumber').on('keyup', function () {
        var amex = $(this).val();
        if (amex.length == 4) {
            amex += ' ';
            $(this).val(amex);
        }
        if (amex.length == 11) {
            amex += ' ';
            $(this).val(amex);
        }
    });

    $('#cardNumber').on('paste', function (e) {
        var currVal = e.originalEvent.clipboardData.getData('text/plain');
        var currVal1 = addStr(currVal, 4, ' ');
        var newVal = addStr(currVal1, 11, ' ');
        $(this).val(newVal);
        return false;
    });
};

function CardGroupForRest() {
    $('#cardNumber').on('keyup', function () {
        var currentCardNo = $(this).val().split(" ").join("");
        if (currentCardNo.length > 0) {
            currentCardNo = currentCardNo.match(new RegExp('.{1,4}', 'g')).join(" ");
        }
        $(this).val(currentCardNo);
    });

    $('#cardNumber').on('paste', function (e) {
        var currVal = e.originalEvent.clipboardData.getData('text/plain');
        var chunks = currVal.match(/.{1,4}/g);
        var newVal = currVal; var counter = 0;
        for (var i = 1; i < chunks.length + 1; i++) {
            newVal = addStr(newVal, (4 * i) + counter, ' ');
            counter++;
        }
        $(this).val(newVal);
        return false;
    });
};

function addStr(str, index, stringToAdd) {
    return str.substring(0, index) + stringToAdd + str.substring(index, str.length);
}


function GroupCardNumber(CardNoControlId, issuerId) {
    var ctrl = $("#" + CardNoControlId);
    if (issuerId != "5" && issuerId != "50000" && issuerId != "50001" && issuerId != "6") {

        var currentCardNo = ctrl.val().split(" ").join("");
        currentCardNo = currentCardNo.match(new RegExp('.{1,4}', 'g')).join(" ");
        ctrl.val(currentCardNo);
        return currentCardNo;
    }
    else {
        var amex = ctrl.val();
        if (amex.length == 4) {
            amex += ' ';
            ctrl.val(amex);
        }
        if (amex.length == 11) {
            amex += ' ';
            ctrl.val(amex);
        }
        if (amex.length >= 14) {
            var currVal = amex.replace(/\s/g, '');
            var currVal1 = addStr(currVal, 4, ' ');
            var newVal = addStr(currVal1, 11, ' ');
            ctrl.val(newVal);
        }
        return amex;
    }
}

function AdjustPadlockPositionLoad() {
    if ($('#okButton').length > 0) {
        var elem = $('#okButton'),
            cs = window.getComputedStyle(elem[0]),
            context = document.createElement("canvas").getContext("2d"),
            metrics, pos;

        context.font = cs.fontSize + " " + cs.fontFamily;
        metrics = context.measureText(elem[0].value.toUpperCase()),
            pos = (elem.width() + metrics.width) / 2 + 20;
        elem.css('background-position', 'calc(100% - ' + pos + 'px) center');
    }
}
function AdjustPadlockPositionLoadMobile() {
    if ($('#payButton').length > 0) {
        var elem = $('#payButton'),
            cs = window.getComputedStyle(elem[0]),
            context = document.createElement("canvas").getContext("2d"),
            metrics, pos;

        context.font = cs.fontSize + " " + cs.fontFamily;
        metrics = context.measureText(elem[0].value.toUpperCase()),
            pos = (elem.width() + metrics.width) / 2 + 20;
        elem.css('background-position', 'calc(100% - ' + pos + 'px) center');
    }
}