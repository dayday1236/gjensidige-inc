﻿function Check3dsMethod(basePath, epaySessionId, cardNumberClientID, expiryMMYYClientID, expiryMonthClientID, expiryYearClientID, issuerId, statusClientId, processButtonClientID) {
    var cardNumberObj = window.document.getElementById(cardNumberClientID);
    var acctNumber = cardNumberObj ? cardNumberObj.value : '';
    var cardExpiryDate = '';
    if (expiryMMYYClientID) {
        var expiryMMYYClientIDObj = window.document.getElementById(expiryMMYYClientID);
        var cardexpiryMMYY = expiryMMYYClientIDObj.value.split('/');
        cardExpiryDate = cardexpiryMMYY[1] + (cardexpiryMMYY[0].length == 1 ? '0' : '') + cardexpiryMMYY[0];// YYMM
    }
    else {
        var expiryMonthObj = window.document.getElementById(expiryMonthClientID);
        var expiryYearObj = window.document.getElementById(expiryYearClientID);
        if (expiryMonthObj && expiryYearObj) {
            var cardExpiryMonth = expiryMonthObj.value;
            var cardExpiryYear = expiryYearObj.value;
            cardExpiryDate = cardExpiryYear.substring(cardExpiryYear.length - 2) + (cardExpiryMonth.length == 1 ? '0' : '') + cardExpiryMonth;// YYMM
        }
    }
    if (document.getElementById("mifCheckbox") != null && document.getElementById("mifCheckbox").checked) {
        issuerId = 3;
    }
    Check3dsMethodByValues(basePath, epaySessionId, acctNumber, cardExpiryDate, issuerId, statusClientId, processButtonClientID)
}

function Check3dsMethodByValues(basePath, epaySessionId, acctNumber, cardExpiryDate, issuerId, statusClientId, processButtonClientID) {
    setStatusMessageTDS(statusClientId, "alert alert-danger", "", true, processButtonClientID);
    try {
        var xmlhttp = null;
        if (window.XMLHttpRequest) {
            // code for modern browsers
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for old IE browsers, in case company policy runs IE in compatibility mode
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        var xmlDoc;
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                xmlDoc = xmlhttp.responseXML;

                var threeDSMethodURL = null;
                var threeDSMethodData = null;
                var errorMessage = null;
                var xmlDocChildNodes = xmlDoc.documentElement.childNodes;
                for (var i = 0; i < xmlDocChildNodes.length; i++) {
                    var xmlDocChild = xmlDocChildNodes[i];
                    var xmlNodeName = xmlDocChild.nodeName;
                    var xmlSubNodes = xmlDocChild.childNodes;
                    var xmlNodeText = xmlSubNodes.length ? xmlSubNodes[0].nodeValue : xmlDocChild.nodeValue;
                    if (xmlNodeName === "threeDSMethodURL")
                        threeDSMethodURL = xmlNodeText;
                    if (xmlNodeName === "threeDSMethodData")
                        threeDSMethodData = xmlNodeText;
                    if (xmlNodeName === "errorMessage")
                        errorMessage = xmlNodeText;
                }
                if (errorMessage) {
                    setStatusMessageTDS(statusClientId, "alert alert-danger", errorMessage, true, processButtonClientID);
                }
                else {
                    if (threeDSMethodURL) {
                        var toolbarButtonsDiv = window.document.getElementById("toolbarButtons");
                        if (toolbarButtonsDiv)
                            toolbarButtonsDiv.style.display = 'block';
                        Begin3dsMethodWithTimeout(threeDSMethodURL, threeDSMethodData);
                    }
                    else {
                        Populate3ds2BrowserData("U");
                    }
                }
            }
            // TODO display error unlock toolbarButtons
        };

        var rememberMeObj = window.document.getElementById('RememberMe');
        var rememberMeElementDef = '';
        if (rememberMeObj) {
            rememberMeElementDef = "<globalWalletData>" + rememberMeObj.value + "</globalWalletData>";
        }

        xmlhttp.open("POST", basePath + "/TDSMethod/Check");
        xmlhttp.setRequestHeader("Content-Type", "text/xml");
        xmlhttp.setRequestHeader("Accept", "text/xml, application/xml");
        var xml = "<?xml version=\"1.0\"?><Check3dsMethodRequest><epaySessionId>" + epaySessionId + "</epaySessionId><acctNumber>" + acctNumber + "</acctNumber><cardExpiryDate>" + cardExpiryDate + "</cardExpiryDate><issuerId>" + issuerId + "</issuerId>" + rememberMeElementDef + "</Check3dsMethodRequest>";
        xmlhttp.send(xml);
    } catch (err) {
        var code = err.toString();
        setStatusMessageTDS(statusClientId, "alert alert-danger", code, false, processButtonClientID);
        return;
    }
}

function setStatusMessageTDS(statusClientId, statusType, textValue, isHtmlValue, processButtonClientID) {
    if (document.getElementById("terminalDesign").value == "true") {
        statusType = "alert alert-danger";
    }
    else {
        statusType = "errorPanel";
    }
    if (textValue) {
        var toolbarButtonsDiv = window.document.getElementById("toolbarButtons");
        if (toolbarButtonsDiv)
            toolbarButtonsDiv.style.display = 'block';
        var backButton = window.document.getElementById("backButton");
        if (backButton)
            backButton.style.display = 'inline';
        var cancelButton = window.document.getElementById("cancelButton");
        if (cancelButton)
            cancelButton.style.display = 'inline';
        var processButton = window.document.getElementById(processButtonClientID);
        if (processButton)
            processButton.style.display = 'inline';
        var progressImageObj = document.getElementById('progressImage');
        if (progressImageObj)
            progressImageObj.style.display = 'none'
        var divMiniTerminal = document.getElementById('divMiniTerminal');
        if (divMiniTerminal && processButton.id === "payButtonMini")
            divMiniTerminal.style.display = 'block';
    }
    var statusClientObj = window.document.getElementById(statusClientId);
    if (statusClientObj) {
        var statusChildNodes = statusClientObj.childNodes;
        for (var i = 0; i < statusChildNodes.length; i++) {
            var statusChild = statusChildNodes[i];
            if (statusChild.nodeType === 1 && statusChild.className.includes(statusType)) {
                var statusChildStyle = statusChild.style;
                if (textValue) {
                    var statusDivChildNodes = statusChild.childNodes;
                    for (var j = 0; j < statusDivChildNodes.length; j++) {
                        var statusDivChild = statusDivChildNodes[j];
                        if (statusDivChild.nodeType === 1 && (statusDivChild.nodeName === "span" || statusDivChild.nodeName === "SPAN")) {
                            SetSpanText(statusDivChild, textValue, isHtmlValue);
                        }
                    }
                    if (statusChildStyle.removeProperty)
                        statusChildStyle.removeProperty('display');
                    else
                        statusChildStyle.display = "";
                }
                else
                    statusChildStyle.display = "none";
            }
        }
    }
    else {
        var errorMessageObj = window.document.getElementById("errorMessage");
        if (errorMessageObj) // custom template
        {
            SetSpanText(errorMessageObj, textValue, isHtmlValue);
        }
    }
}

function SetSpanText(statusDivChild, textValue, isHtmlValue) {
    if (isHtmlValue)
        statusDivChild.innerHTML = textValue;
    else {
        statusDivChild.innerHTML = ""; //removing all children
        var textValueNode = document.createTextNode(textValue);
        statusDivChild.appendChild(textValueNode);
    }
}

function On3dsMethodComplete(threeDSMethodData) {
    if (window.tdsMethodTimer)
        window.clearTimeout(window.tdsMethodTimer);
    if (window.continueOn3dsMethodComplete)
        Populate3ds2BrowserData("Y", threeDSMethodData);
}

function Populate3ds2BrowserData(threeDSCompInd, threeDSMethodData) {
    var aspNetForm = window.document.forms[0];
    Ensure3DS2InputElement(aspNetForm, "hidden", "hdnThreeDSCompInd", threeDSCompInd);

    Ensure3DS2InputElement(aspNetForm, "hidden", "hdnBrowserJavaEnabled", navigator.javaEnabled());
    Ensure3DS2InputElement(aspNetForm, "hidden", "hdnBrowserJavascriptEnabled", "true");
    Ensure3DS2InputElement(aspNetForm, "hidden", "hdnBrowserLanguage", (navigator.language || navigator.browserLanguage));
    Ensure3DS2InputElement(aspNetForm, "hidden", "hdnBrowserColorDepth", screen.colorDepth);
    Ensure3DS2InputElement(aspNetForm, "hidden", "hdnBrowserScreenHeight", screen.height);
    Ensure3DS2InputElement(aspNetForm, "hidden", "hdnBrowserScreenWidth", screen.width);
    Ensure3DS2InputElement(aspNetForm, "hidden", "hdnBrowserTZ", new Date().getTimezoneOffset());
    ContinueAfter3dsMethod(threeDSMethodData);
}

function Ensure3DS2InputElement(theForm, theType, theName, theValue) {
    var input1 = theForm.elements.namedItem(theName);
    if (!input1) {
        input1 = document.createElement("input");
        input1.setAttribute('type', theType);
        input1.setAttribute('name', theName);
        theForm.appendChild(input1);
    }
    input1.value = theValue;
}

function Begin3dsMethodWithTimeout(threeDSMethodURL, threeDSMethodData) {
    window.tdsMethodTimer = window.setTimeout(function () {
        window.continueOn3dsMethodComplete = false;
        Populate3ds2BrowserData("N");
    }, 5000);
    Begin3dsMethod(threeDSMethodURL, threeDSMethodData)
}

function Begin3dsMethod(threeDSMethodURL, threeDSMethodData) {
    window.continueOn3dsMethodComplete = true;
    var tdsMmethodTgtFrame = window.document.getElementById("tdsMmethodTgtFrame");
    if (!tdsMmethodTgtFrame) {
        tdsMmethodTgtFrame = window.document.createElement('iframe');
        tdsMmethodTgtFrame.id = "tdsMmethodTgtFrame";
        tdsMmethodTgtFrame.setAttribute('name', 'tdsMmethodTgtFrame');
        var iframeStyle = tdsMmethodTgtFrame.style;
        iframeStyle.width = "1px";
        iframeStyle.height = "1px";
        iframeStyle.visibility = "hidden";
        tdsMmethodTgtFrame.setAttribute('src', 'about:blank');
        document.body.appendChild(tdsMmethodTgtFrame);
    }
    var tdsMmethodForm = window.document.getElementById("tdsMmethodForm");
    if (!tdsMmethodForm) {
        tdsMmethodForm = document.createElement("form");
        tdsMmethodForm.id = "tdsMmethodForm";
        tdsMmethodForm.setAttribute('name', 'tdsMmethodForm');
        tdsMmethodForm.setAttribute('target', 'tdsMmethodTgtFrame');
        tdsMmethodForm.setAttribute('action', threeDSMethodURL);
        tdsMmethodForm.setAttribute('method', "post");
        document.body.appendChild(tdsMmethodForm);
    }
    else
        tdsMmethodForm.setAttribute('action', threeDSMethodURL);

    var input0 = tdsMmethodForm.elements.namedItem("3DSMethodData");
    if (input0)
        input0.value = threeDSMethodData;
    Ensure3DS2InputElement(tdsMmethodForm, "hidden", "threeDSMethodData", threeDSMethodData);

    tdsMmethodForm.submit();
}
